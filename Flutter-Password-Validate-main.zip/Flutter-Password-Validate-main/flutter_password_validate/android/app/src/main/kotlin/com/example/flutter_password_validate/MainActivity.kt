package com.example.flutter_password_validate

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
